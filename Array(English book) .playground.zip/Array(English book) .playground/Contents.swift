import UIKit

var evenNumbers = [2,4,5,6]  //mutable array


var subscribers: [String] = [] //create empty array

let allZeroz = [Int](repeating: 200, count: 7) // array with 200 value 7 repeating

let aaZerosInferred = Array(repeating: 5, count: 10) // also can

///////////////////////////////////
var players = ["Alice","Bob","Cindy","Ban","Amo","Sergey","Kelli"]

// print last name in array players
print(players[players.count - 1])
print(players.last)

if players.count < 2 {
    print("Too few players")
} else {
    print("Go on")
}
///////////////////////////////////////
let currentPlayer = players.min()
if  let currentPlayer =  currentPlayer {
    print("This player is \(currentPlayer)")
}
////////////////////////////////////////

//Use index
var firstPlayer = players[0]
print("First player is \(firstPlayer)")

////////////////
//Use diapozon
let upcomingPlayers = players[1...2]
print(upcomingPlayers)
//////////////////////


func isEliminated(player:String) -> Bool{
    return players.contains(player)
    
}

isEliminated(player: "Bob")
///////////////////


// index player Dan will be...
let indexDan = players.index(of: "Bob")
let bob = players[indexDan!]

//Change name Bob on the Franklin
players[1] = "Franklin"

//sort players
players.sort(){$0 < $1}  //its working
print(players)

for player in players{
    print(player)
}


let scores = [1,4,6,7,8,4,1]

func allScores(array: [Int]) -> Int{
     var sum = 0
    for i in array{
        sum += i
    }
    return sum
}







